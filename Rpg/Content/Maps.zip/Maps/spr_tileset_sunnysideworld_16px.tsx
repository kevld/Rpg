<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.6" name="spr_tileset_sunnysideworld_16px" tilewidth="16" tileheight="16" tilecount="4096" columns="64">
 <image source="spr_tileset_sunnysideworld_16px.png" width="1024" height="1024"/>
</tileset>
